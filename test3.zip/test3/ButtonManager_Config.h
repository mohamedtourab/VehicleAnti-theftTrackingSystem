#ifndef	BUTTON_MANAGER_CONFIG_H
#define	BUTTON_MANAGER_CONFIG_H

// Determine the number of used buttons
#define NUMBER_OF_BUTTONS	1U

#endif