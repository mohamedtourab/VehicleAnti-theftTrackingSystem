#ifndef NVM_CONFIG_H
#define NVM_CONFIG_H

#define NO_OF_NVM_USED  (2U)
#define MEMORY_SIZE 	(1024)
#define NVM_CYCLIC_TIME (1U)

#endif