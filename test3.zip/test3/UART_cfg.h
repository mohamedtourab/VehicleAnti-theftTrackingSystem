#ifndef UART_CFG_H
#define UART_CFG_H

#define UART_PERIF_NUM 5U
#define UART_USE_INT_TO_HANDLE 1U
#endif
