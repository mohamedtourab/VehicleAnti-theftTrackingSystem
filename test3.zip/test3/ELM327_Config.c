
/**************************************************************************************
*File name: ELM327_Config.c
*Auther :edited by the user
*Date: 30/4/2018
*Description:
*       This file contains:
*               - A structurs that containes the Groups to manage the ELM327
*Microcontroller: STM32F407VG
***************************************************************************************/ 
#include "ELM327.h"
#include "APP.h"

void Error_CallBack(uint8_t ErrorID);

const ELM327_ConfigType ELM327_ConfigParam = 
{
	/*UART channel Id*/
	3,
	&VehicleStatusCallBackFn,&VehicleStatusCallBackFn,&VehicleStatusCallBackFn,&VehicleStatusCallBackFn,&Error_CallBack
};

