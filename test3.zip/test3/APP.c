/**************************************************************************************
*File name: APP.c
*Author:
*		-Abdelrhman Hosny
*		-Amr Mohamed
*		-Moamen Ali 
*		-Moamen Ramadan 
*Date: 21/6/2018
*Description:
*	This file contains:
*		- implementation of functions used to manage the Application
*Microcontroller: STM32F407VG
***************************************************************************************/

#include "APP.h"
#define ELM_Timeout	(1000U/APP_CYCLIC_TIME)
#define GSM_Timeout	(1000U/APP_CYCLIC_TIME)


/***********************************************************************************
**********						DEFINEED MACROS								********
***********************************************************************************/

#define EXPIRE_TIME					100000U


//the time delays used in this file
#define T_EXP 	(EXPIRE_TIME/GSM_CYCLIC_TIME)


#define REQUEST_SERVICE_STATE			0U
#define WAITING_FOR_RESPONSE_STATE		1U

/***********************************************************************************
**********                      ENUM Declarations	                         ********
***********************************************************************************/

typedef enum
{
	UNINIT_STATE = 0,
	OBD_NON_AUTH_STATE,
	OBD_AUTH_STATE,
	GET_AUTH_STATE,
	WARNING_MESSAGE_STATE,
	GPS_DATA_STATE,
	SERVER_MESSAGE_STATE,
	ERROR_STATE
}APP_AuthManageStates;

typedef enum
{
	UNINIT_LOC_STATE = 0,
	IDLE_LOC_STATE,
	GPS_DATA_LOC_STATE,
	SERVER_LOC_MESSAGE_STATE,
	ERROR_LOC_STATE
}APP_StaticLocManageStates;


/***********************************************************************************
**********				APP Helper functions prototypes						********
***********************************************************************************/

static APP_CheckType RequestVehicleStatus(void);
static uint8_t VehicleHelper;

static APP_CheckType RequestAuthenticationStatus(void);
static uint8_t AuthHelper;

static APP_CheckType WarningMessage (void);
static uint8_t WarningHelper;

static APP_CheckType GetGPSData (void);
static uint8_t GPSHelper;

static APP_CheckType SendServerData (void);
static uint8_t ServerHelper;

/***********************************************************************************
**********                      Declare Globals                             ********
***********************************************************************************/
/*global variable to hold the states of the Authantication ManageOperation */
static APP_AuthManageStates APP_AuthManageState;
/*global variable to hold the states of the Static Location ManageOperation */
static APP_StaticLocManageStates APP_StaticLocManageState;
/*global variable to hold state of the helper functions*/
static uint8_t APP_HelperState;

/*variable that hold the car status requested from OBD*/
static OBD_VehicleStatus APP_VehicleState;

/*variable that hold the authentication status requested from PasswordManager*/
static AuthenticationStatus APP_AuthenticationStatus;

/*global variable to wait for response of the service requested*/
static uint8_t Vehicle_SuccessFlag;

/*global variable to wait for response of the service requested*/
static uint8_t GPS_SuccessFlag;

/*global variable to wait for response of the service requested*/
static uint8_t Server_SuccessFlag;

/*global variable to wait for response of the service requested*/
static uint8_t Warning_SuccessFlag;

/*global variable to wait for response of the service requested*/
static uint8_t Auth_SuccessFlag;

/*a flag that get set when the data handler receives the get location command*/
static uint8_t APP_GetCrntLocFlag;
/*global variable to store the location was read from GPS*/
static Location Map;

/*Global variable to send warning message only one time*/
static uint8_t APP_WarningMessageSent;

/*counter for the time out actions*/
static uint32_t APP_MaxResponseTimeCounter;

// global variable to be set in the callback function of GPS to indicate that GPS is ready
static uint8_t APP_GPSFirstData;

/***********************************************************************************
**********                      APP functions' bodies                      ********
***********************************************************************************/

/*
 * This function is used to initialize the flags for the functions called by the ManageOngoingOperation function 
 * Inputs:NONE
 * Output:NONE
*/

void APP_Init(void)
{
	APP_AuthManageState = UNINIT_STATE;
	APP_HelperState = REQUEST_SERVICE_STATE;
	APP_StaticLocManageState = UNINIT_LOC_STATE;
	APP_VehicleState = OBD_PARKED_STATE;
	VehicleHelper = REQUEST_SERVICE_STATE;
	GPSHelper = REQUEST_SERVICE_STATE;
	AuthHelper = REQUEST_SERVICE_STATE;
	WarningHelper = REQUEST_SERVICE_STATE;
	ServerHelper = REQUEST_SERVICE_STATE;
	Vehicle_SuccessFlag = 0;
	GPS_SuccessFlag = 0;
	Server_SuccessFlag = 0;
	Warning_SuccessFlag = 0;
	Auth_SuccessFlag = 0;

	APP_WarningMessageSent = 0;

	APP_AuthenticationStatus = NON_AUTH;

	APP_MaxResponseTimeCounter = 0;
	APP_GPSFirstData = 0;
}

/*
 * This function is a FSM to manage the on going operations of the Authantication and car moving
 *Inputs:NONE
 * Output:NONE
*/

void APP_AuthManageOnGoingOperations(void)
{
	APP_CheckType Check = APP_BSY;

	switch(APP_AuthManageState)
	{
		case UNINIT_STATE:
		{
			if (APP_GPSFirstData == 1)
			{
				GPS_SuccessFlag = 1;
				APP_AuthManageState = OBD_NON_AUTH_STATE;
			}
			else {/*Wait for GPS to finish Initialization*/}
			break;
		}

		case OBD_NON_AUTH_STATE:
		{
			Check = RequestVehicleStatus();

			if(Check == APP_OK)/*Check == APP_OK*/
			{
				if((APP_VehicleState == OBD_STARTED_STATE) && (APP_WarningMessageSent == 0))
				{
					APP_AuthManageState = GET_AUTH_STATE;
				}
				else if((APP_VehicleState == OBD_MOVING_STATE) && (APP_WarningMessageSent == 0))
				{
					APP_AuthManageState = WARNING_MESSAGE_STATE;
				}
				else if((APP_VehicleState != OBD_PARKED_STATE) && (APP_WarningMessageSent == 1))
				{
					APP_AuthManageState = GPS_DATA_STATE;
				}
				else
				{
					APP_WarningMessageSent = 0;
					/*this means that the vehicle is already parked, so we should check
					 vehicle speed again until it changes*/
				}

				VehicleHelper = REQUEST_SERVICE_STATE;
			}
			else if(Check == APP_NOK)
			{
				VehicleHelper = REQUEST_SERVICE_STATE;

				APP_AuthManageState = ERROR_STATE;
			}
			else
			{
				/*the Check is initialized to BSY so no action is needed here*/
			}

			break;
		}

		case OBD_AUTH_STATE:
		{
			Check = RequestVehicleStatus();

			if(Check == APP_OK)
			{
				if(APP_VehicleState == OBD_PARKED_STATE)
				{
					APP_AuthenticationStatus = NON_AUTH;
					APP_WarningMessageSent = 0;
					
					APP_AuthManageState = OBD_NON_AUTH_STATE;
				}
				else
				{
					/*this means that the vehicle is moving with authentication*/
				}

				VehicleHelper = REQUEST_SERVICE_STATE;
			}
			else if(Check == APP_NOK)
			{
				VehicleHelper = REQUEST_SERVICE_STATE;

				APP_AuthManageState = ERROR_STATE;
			}
			else
			{
				/*the Check is initialized to BSY so no action is needed here*/
			}

			break;
		}

		case GET_AUTH_STATE:
		{
			Check = RequestAuthenticationStatus();

			if(Check == APP_OK)
			{
				if(APP_AuthenticationStatus == AUTH)
				{
					APP_AuthManageState = OBD_AUTH_STATE;
				}
				else
				{
					APP_AuthManageState = OBD_NON_AUTH_STATE;
				}

				AuthHelper = REQUEST_SERVICE_STATE;
			}
			else if(Check == APP_NOK)
			{
				AuthHelper = REQUEST_SERVICE_STATE;

				APP_AuthManageState = ERROR_STATE;
			}
			else
			{
				/*the Check is initialized to BSY so no action is needed here*/
			}

			break;
		}

		case WARNING_MESSAGE_STATE:
		{
			Check = WarningMessage();

			if(Check == APP_OK)
			{
				APP_AuthManageState = OBD_NON_AUTH_STATE;

				WarningHelper = REQUEST_SERVICE_STATE;

				APP_WarningMessageSent = 1;
			}
			else if(Check == APP_NOK)
			{
				WarningHelper = REQUEST_SERVICE_STATE;

				APP_AuthManageState = ERROR_STATE;
			}
			else
			{
				/*the Check is initialized to BSY so no action is needed here*/
			}

			break;
		}

		case GPS_DATA_STATE:
		{
			Check = GetGPSData();

			if(Check == APP_OK)
			{
				APP_AuthManageState = SERVER_MESSAGE_STATE;
				GPSHelper = REQUEST_SERVICE_STATE;
			}
			else if(Check == APP_NOK)
			{
				GPSHelper = REQUEST_SERVICE_STATE;

				APP_AuthManageState = ERROR_STATE;
			}
			else
			{
				/*the Check is initialized to BSY so no action is needed here*/
			}

			break;
		}

		case SERVER_MESSAGE_STATE:
		{
			Check = SendServerData();
			if(Check == APP_OK)
			{
				APP_AuthManageState = OBD_NON_AUTH_STATE;					

				ServerHelper = REQUEST_SERVICE_STATE;
			}
			else if(Check == APP_NOK)
			{
				ServerHelper = REQUEST_SERVICE_STATE;

				APP_AuthManageState = ERROR_STATE;
			}
			else
			{
				/*the Check is initialized to BSY so no action is needed here*/
			}
			break;
		}

		case ERROR_STATE:
		{
			APP_AuthManageState = OBD_NON_AUTH_STATE;

			break;
		}

		default:
		{
			break;
		}
	}
}

void APP_LocManageOnGoingOperations(void)
{
	APP_CheckType Check = APP_BSY;

	switch (APP_StaticLocManageState)
	{
		case UNINIT_LOC_STATE:
		{
			if (APP_GPSFirstData == 1)
			{
				GPS_SuccessFlag = 0;
				APP_StaticLocManageState = IDLE_LOC_STATE;
			}
			else{/*Wait for GPS to finish Initialization*/}
			break;
		}

		case IDLE_LOC_STATE:
		{
			if (APP_GetCrntLocFlag)
			{
				APP_StaticLocManageState = GPS_DATA_LOC_STATE;
			}
			else{/*wait for a message from user to request the GPS data*/}
			break;
		}

		case GPS_DATA_LOC_STATE:
		{
			Check = GetGPSData();
			if(Check == APP_OK)
			{
				APP_StaticLocManageState = SERVER_LOC_MESSAGE_STATE;
				GPSHelper = REQUEST_SERVICE_STATE;
			}
			else if(Check == APP_NOK)
			{
				GPSHelper = REQUEST_SERVICE_STATE;

				APP_StaticLocManageState = ERROR_LOC_STATE;
			}
			else
			{
				/*the Check is initialized to BSY so no action is needed here*/
			}
			break;
		}

		case SERVER_LOC_MESSAGE_STATE:
		{
			Check = SendServerData();
			if(Check == APP_OK)
			{	
				APP_GetCrntLocFlag = 0;	
				APP_StaticLocManageState = IDLE_LOC_STATE;
				ServerHelper = REQUEST_SERVICE_STATE;
			}
			else if(Check == APP_NOK)
			{
				APP_GetCrntLocFlag = 0;
				ServerHelper = REQUEST_SERVICE_STATE;

				APP_StaticLocManageState = ERROR_LOC_STATE;
			}
			else
			{
				/*the Check is initialized to BSY so no action is needed here*/
			}
			break;
		}

		case ERROR_LOC_STATE:
		{
			APP_StaticLocManageState = IDLE_LOC_STATE;
			break;
		}
	}		
}


/***********************************************************************************
**********						APP call back functions						********
***********************************************************************************/

/*
 * This function callback function From the ELM327 Driver it is called when it finishes reading the Vehicle Status  
 * Inputs:
 *		- Status 		: the status of the vehicle
 * Output:NONE
*/

void VehicleStatusCallBackFn(OBD_VehicleStatus Status)
{
	APP_VehicleState = Status;
	Vehicle_SuccessFlag =1;
}

/*
 * This function callback function From the password manager it is called when it finishes reading the authantication Status  
 * Inputs:
 *		- Status 		: the status of the authantication
 * Output:NONE
*/

void AuthenticattionStatusCallBackFn(AuthenticationStatus Status)
{
	APP_AuthenticationStatus = Status;
	Auth_SuccessFlag = 1;
	if (Status != AUTH)
	{
		GPIO_Write(8,PIN_MASK_13,HIGH);
		//APP_VehicleState = OBD_MOVING_STATE;
	}
	else
	{
		GPIO_Write(8,PIN_MASK_14,HIGH);
	}
}

/*
 * This function callback function From the GSM Manager it is called when it finishes sending the warning message
 * Inputs:
 *		- Status 		: the status of the authantication
 * Output:NONE
*/

void WarningMessageCallBackFn (void)
{
	GPIO_Write(13,PIN_MASK_0,HIGH);
	Warning_SuccessFlag = 1;
}

/*
 * This function callback function From the GPS Manager it is called when it finishes reading the location
 * Inputs:NONE
 * Output:NONE
*/

void LocationFound (void)
{
	APP_GPSFirstData = 1;
	GPS_SuccessFlag = 1;
}

/*
 * This function callback function From the GSM Manager it is called when it finishes sending the location to the server
 * Inputs:NONE
 * Output:NONE
*/

void ServerMessageCallBackFn (void)
{
	GPIO_Write(13,PIN_MASK_1,HIGH);
	Server_SuccessFlag = 1;
}

/*
 * This function callback function From the Data Handler it is called when it receives the get location Command
 * Inputs:NONE
 * Output:NONE
*/

void GetLocCMDCallBackFn(void)
{
	GPIO_Write(13,PIN_MASK_2,HIGH);
	APP_GetCrntLocFlag = 1;
}





/***********************************************************************************
**********							Helper functions						********
***********************************************************************************/

/*
 * This function is a FSM to request the vehicle status
 * Inputs:NONE
 * Output:
 *		- an indication of the success of the function
*/

static APP_CheckType RequestVehicleStatus(void)
{
	APP_CheckType RetVar = APP_BSY;

	switch(VehicleHelper)
	{
		case REQUEST_SERVICE_STATE:
		{
			ELM327_GetVehicleSpeed();				//call the OBD API

			VehicleHelper = WAITING_FOR_RESPONSE_STATE;	//go to the next state

			APP_MaxResponseTimeCounter=0;			//initilize the response time counter with 0

			break;
		}

		case WAITING_FOR_RESPONSE_STATE:
		{
			//check the state of the command success
			if (Vehicle_SuccessFlag == 1)
			{
				Vehicle_SuccessFlag = 0;

				RetVar = APP_OK;
			}
			else
			{
				if(APP_MaxResponseTimeCounter < ELM_Timeout)
				{
					APP_MaxResponseTimeCounter++;
				}
				else
				{
					APP_MaxResponseTimeCounter = 0;
					RetVar = APP_NOK; 
				}
			}

			break;
		}

		default:
		{
			RetVar = APP_NOK; 
			break;
		}
	}
	return RetVar;
}

/*
 * This function is a FSM to request the authantication status
 * Inputs:NONE
 * Output:
 *		- an indication of the success of the function
*/

static APP_CheckType RequestAuthenticationStatus(void)
{
	APP_CheckType RetVar = APP_BSY;

	switch(AuthHelper)
	{
		case REQUEST_SERVICE_STATE:
		{
			GetPasswordStatus();							//call the Password Manager API

			AuthHelper = WAITING_FOR_RESPONSE_STATE;	//go to the next state

			APP_MaxResponseTimeCounter=0;				//initilize the response time counter with 0

			break;
		}

		case WAITING_FOR_RESPONSE_STATE:
		{
			//check the state of the command success
			if (Auth_SuccessFlag == 1)
			{
				Auth_SuccessFlag = 0;

				RetVar = APP_OK;
			}
			else
			{
				if(APP_MaxResponseTimeCounter < T_EXP)
				{
					APP_MaxResponseTimeCounter++;
				}
				else
				{
					APP_MaxResponseTimeCounter = 0;
					RetVar = APP_NOK; 
				}
			}

			break;
		}

		default:
		{
			RetVar = APP_NOK; 
			break;
		}
	}
	return RetVar;
}

/*
 * This function is a FSM to request sending a warning message
 * Inputs:NONE
 * Output:
 *		- an indication of the success of the function
*/

static APP_CheckType WarningMessage (void)
{
	APP_CheckType RetVar = APP_BSY;

	switch(WarningHelper)
	{
		case REQUEST_SERVICE_STATE:
		{
			DH_SendWarningSMS();							//call Warning Message API

			WarningHelper = WAITING_FOR_RESPONSE_STATE;	//go to the next state

			APP_MaxResponseTimeCounter=0;				//initilize the response time counter with 0

			break;
		}

		case WAITING_FOR_RESPONSE_STATE:
		{
			//check the state of the command success
			if (Warning_SuccessFlag == 1)
			{
				Warning_SuccessFlag = 0;

				RetVar = APP_OK;
			}
			else
			{
				if(APP_MaxResponseTimeCounter < T_EXP)
				{
					APP_MaxResponseTimeCounter++;
				}
				else
				{
					APP_MaxResponseTimeCounter = 0;
					RetVar = APP_NOK; 
				}
			}

			break;
		}

		default:
		{
			RetVar = APP_NOK; 
			break;
		}
	}
	return RetVar;	
}

/*
 * This function is a FSM to request the GPS location
 * Inputs:NONE
 * Output:
 *		- an indication of the success of the function
*/

static APP_CheckType GetGPSData (void)
{
	APP_CheckType RetVar = APP_BSY;

	switch(GPSHelper)
	{
		case REQUEST_SERVICE_STATE:
		{
			StartRead();									//call Start GPS Read API

			GPSHelper = WAITING_FOR_RESPONSE_STATE;	//go to the next state

			APP_MaxResponseTimeCounter=0;				//initilize the response time counter with 0

			break;
		}

		case WAITING_FOR_RESPONSE_STATE:
		{
			//check the state of the command success
			if (GPS_SuccessFlag == 1)
			{
				GPS_SuccessFlag = 0;

				GetData(&Map);

				RetVar = APP_OK;
			}
			else
			{
				if(APP_MaxResponseTimeCounter < T_EXP)
				{
					APP_MaxResponseTimeCounter++;
				}
				else
				{
					APP_MaxResponseTimeCounter = 0;
					RetVar = APP_NOK; 
				}
			}

			break;
		}

		default:
		{
			RetVar = APP_NOK; 
			break;
		}
	}
	return RetVar;	
}

/*
 * This function is a FSM to request sending the location to the server
 * Inputs:NONE
 * Output:
 *		- an indication of the success of the function
*/
static uint32_t SCounter = 0;
static APP_CheckType SendServerData (void)
{
	APP_CheckType RetVar = APP_BSY;
	if (SCounter > 2000)
	{
	switch(ServerHelper)
	{
		case REQUEST_SERVICE_STATE:
		{
			DH_SendLocationToServer(&Map);					//call Server Message API

			//DH_SendLocationSMS(&Map);

			ServerHelper = WAITING_FOR_RESPONSE_STATE;	//go to the next state

			APP_MaxResponseTimeCounter=0;				//initilize the response time counter with 0

			break;
		}

		case WAITING_FOR_RESPONSE_STATE:
		{
			//check the state of the command success
			if (Server_SuccessFlag == 1)
			{
				Server_SuccessFlag = 0;

				RetVar = APP_OK;
			}
			else
			{
				if(APP_MaxResponseTimeCounter < GSM_Timeout)
				{
					APP_MaxResponseTimeCounter++;
				}
				else
				{
					APP_MaxResponseTimeCounter = 0;
					RetVar = APP_NOK; 
				}
			}

			break;
		}

		default:
		{
			RetVar = APP_NOK; 
			break;
		}
	}
	SCounter = 0;
	}
	else
	{
		SCounter++;
	}
	return RetVar;	
}