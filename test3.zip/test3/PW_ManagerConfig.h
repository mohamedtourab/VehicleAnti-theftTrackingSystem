#ifndef PW_MANAGER_CONFIG_H
#define PW_MANAGER_CONFIG_H

// the Length of the PW in bytes
#define PW_LENGTH	4U

// cyclic time of the PW_manager function 
#define PW_MANAGER_CYCLIC_CTIME		10U
#endif