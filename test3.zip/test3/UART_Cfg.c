#include "UART.h"
#include "UART_cfg.h"
#include "BT_Driver.h"
#include "GSM_Driver.h"
#include "GPS.h"
#include "ELM327.h"
#include "KeyManager.h"
//void Test(void);
const UART_ConfigType UART_ConfigParam[UART_PERIF_NUM] =
{
	// Bluetooth UART
  {
	     UART_6,0,
       BR115200,NOPARITY,STOP_ONE,UART_8_BITS,
       UART_TransmissionDone,UART_ReceptionDone
		//Test,Test
  },

  // GSM UART
  {
	     UART_2,1,
       BR9600,NOPARITY,STOP_ONE,UART_8_BITS,
       GSM_DriverTxCallBackFn,GSM_DriverRxCallBackFn
  },

  // GPS UART
  {
	     UART_5,2,
       BR9600,NOPARITY,STOP_ONE,UART_8_BITS,
       GPS_ReceptionCallBack,GPS_ReceptionCallBack
  },

  // OBD UART
  {
	     UART_3,3,
       BR38400,NOPARITY,STOP_ONE,UART_8_BITS,
       ELM327_TxCallBackFn,ELM327_RxCallBackFn
  },

  // KeyManager UART
  {
	     UART_1,4,
       BR9600,NOPARITY,STOP_ONE,UART_8_BITS,
       key_ReceptionDone,key_ReceptionDone
  }
};