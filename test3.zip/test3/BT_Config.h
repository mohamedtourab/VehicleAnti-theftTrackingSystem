#ifndef BT_CONFIG_H
#define BT_CONFIG_H

#include <stdint.h>

#define BT_CYCLIC_TIME (10U)

#endif /*end of BT_CONFIG_H*/

