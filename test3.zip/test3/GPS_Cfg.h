#ifndef GPS_CONFIG_H
#define GPS_CONFIG_H

#define	ERROR_ID	2U

#endif