/**************************************************************************************
*File name: DataHandlerConfig.c
*Auther :edited by the user
*Date: 13/6/2018
*Description:
*       This file contains:
*               - A structurs that containes the DataHandler configurations 
*Microcontroller: STM32F407VG
***************************************************************************************/ 
#include "DataHandler.h"
#include "APP.h"

void Error_CallBack(uint8_t ErrorID);

uint8_t W_MSG[8] = {'W','a','r','n','i','n','g',26};

const DataHandlerConfigType DataHandlerConfigParam =
{
	/*Warning message to be sent*/
	W_MSG,

	/*length of warning message*/
	8,

	/*phone number*/
	"01281479865",

	"156.219.169.23",
	14,

	"350",

	3,

	/*UART Channel number*/
	"LOC",

	3,


	/*a pointer to a call back function*/
	WarningMessageCallBackFn,
	ServerMessageCallBackFn,

	GetLocCMDCallBackFn,


	/*a pointer to the error callback function*/
	Error_CallBack

};