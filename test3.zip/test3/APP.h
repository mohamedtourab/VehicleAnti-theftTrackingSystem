/**************************************************************************************
*File name: APP.h
*Author:
*		-Abdelrhman Hosny
*		-Amr Mohamed
*		-Moamen Ali 
*		-Moamen Ramadan 
*Date: 21/6/2018
*Description:
*	This file contains:
*		-macros to control the Application layer
*		-prototype of the APIs of the Application
*Microcontroller: STM32F407VG
***************************************************************************************/
#ifndef APP_H
#define APP_H

#include "ELM327.h"
#include "PW_Manager.h"
#include "GPS.h"
#include "DataHandler.h"
#include "APP_Config.h"

/***********************************************************************************
**********                      Defined data types                              ****
***********************************************************************************/

//data type for the return values in the Application
typedef enum 
{APP_OK=0, APP_NOK, APP_BSY}APP_CheckType;


/***********************************************************************************
**********                      Functions prototypes                        ********
***********************************************************************************/

//----------------------------- GSM driver back function --------------------------

/*
 * This function callback function From the ELM327 Driver it is called when it finishes reading the Vehicle Status  
 * Inputs:
 *		- Status 		: the status of the vehicle
 * Output:NONE
*/
void VehicleStatusCallBackFn(OBD_VehicleStatus Status);

/*
 * This function callback function From the password manager it is called when it finishes reading the authantication Status  
 * Inputs:
 *		- Status 		: the status of the authantication
 * Output:NONE
*/

void AuthenticattionStatusCallBackFn(AuthenticationStatus Status);

/*
 * This function callback function From the GSM Manager it is called when it finishes sending the warning message
 * Inputs:
 *		- Status 		: the status of the authantication
 * Output:NONE
*/

void WarningMessageCallBackFn (void);

/*
 * This function callback function From the GPS Manager it is called when it finishes reading the location
 * Inputs:NONE
 * Output:NONE
*/

void LocationFound (void);

/*
 * This function callback function From the GSM Manager it is called when it finishes sending the location to the server
 * Inputs:NONE
 * Output:NONE
*/

void ServerMessageCallBackFn (void);

/*
 * This function callback function From the Data Handler it is called when it receives the get location Command
 * Inputs:NONE
 * Output:NONE
*/

void GetLocCMDCallBackFn(void);


//--------------------------------- API functions ---------------------------

/*
 * This function is used to initialize the flags for the functions called by the ManageOngoingOperation function 
 * Inputs:NONE
 * Output:NONE
*/
void APP_Init(void);

/*
 * This function is a FSM to manage the on going operations of the Authantication and car moving
 *Inputs:NONE
 * Output:NONE
*/

void APP_AuthManageOnGoingOperations(void);

void APP_LocManageOnGoingOperations(void);
#endif