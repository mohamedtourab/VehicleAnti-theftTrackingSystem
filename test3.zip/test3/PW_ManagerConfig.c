#include "PW_Manager.h"
#include "APP.h"
const PW_ConfigParameters	PW_Configuration = 
{
	"1111",					 			// password
	0,									//block ID in NVM where the key is stored
	1,									// Block ID in NVM where the key status is stored either default or changed
	AuthenticattionStatusCallBackFn		// callback function to get the authentication status
};