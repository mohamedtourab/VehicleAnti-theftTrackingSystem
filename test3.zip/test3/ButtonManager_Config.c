#include "ButtonManager.h"
#include "ButtonManager_Config.h"

ButtonConfigParameters	Buttons[NUMBER_OF_BUTTONS]=
{
	{
		9,				// Channel ID of the button in GPIO_Cfg.c
		PIN_MASK_15,		// the pin mask of the used pin
		PUPD_PULLDOWN		// the state of button pulled up or down
	}
};
