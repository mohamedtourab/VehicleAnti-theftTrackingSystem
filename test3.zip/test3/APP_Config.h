/**************************************************************************************
*File name: APP_Config.h
*Auther : edited by the user
*Date: 21/6/2018
*Description:
*	This file contains:
*		- A macro that containes the the cyclic time witch the functions get called periodicly with
*Microcontroller: STM32F407VG
***************************************************************************************/ 

#ifndef APP_CONFIG_H
#define APP_CONFIG_H

//the cyclic time witch the functions get called periodicly with
#define APP_CYCLIC_TIME 50U



#endif