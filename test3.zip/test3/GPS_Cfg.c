#include "GPS.h"
#include "GPIO.h"
#include "APP.h"
void Error_CallBack(uint8_t ErrorID);

const GPS_Config GPS_Parameter = 
{
	2,	// The index of the UART channel in the Configuration Parameter array defined in UART_Cfg.c
	7,	// The index of the Force pin channel in the configuration parameter defined in GPIO_Cfg.c
	PIN_MASK_4,	// The pin mask used for Force pin
	6, // The index of the Reset pin channel in the configuration parameter defined in GPIO_Cfg.c
	PIN_MASK_1,	// The pin mask used for Reset pin
	LocationFound,	// CallBack function that will be executed in case of finding the data in GPS readeings
	Error_CallBack	// CallBack function that will be executed in case the data is not found
};