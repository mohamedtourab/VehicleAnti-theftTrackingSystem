#include "GPIO.h"
#include "UART.h"
#include "I2C_Driver.h"
#include "I2C_Manager.h"
#include "GPS.h"
#include "GSM.h"
#include "BT_Driver.h"
#include "BT_Manager.h"
#include "ELM327.h"
#include "DataHandler.h"
#include "ButtonManager.h"
#include "KeyManager.h"
#include "PW_Manager.h"
#include "NVM_Manager.h"
#include "APP.h"
#include "FreeRTOS.h"
#include "task.h"
#include "stm32f4xx.h"

extern uint8_t NVM_SuccesWrite;
uint8_t KeySt[2] = {1,0};
#define STACK_SIZE 1000
uint8_t count = 1;
/*void UART9600_Task(void* PvParameter)
{
    TickType_t PreviousWakeTime;
    const TickType_t UART9600_Cyclic = 100;
    PreviousWakeTime = xTaskGetTickCount();
    while (1)
    {
        UART_ManageOngoingOperation(0);
        UART_ManageOngoingOperation(1);
        vTaskDelayUntil(&PreviousWakeTime, UART9600_Cyclic);
    }
}*/

/*void GSM_Task(void* PvParameter)
{
    TickType_t PreviousWakeTime;
    const TickType_t GSM_Cyclic = 200;
    PreviousWakeTime = xTaskGetTickCount();
    while (1)
    {
        GSM_ManageOngoingOperation();
        vTaskDelayUntil(&PreviousWakeTime, GSM_Cyclic);
    }
}*/

/*void ELM327_Task(void* PvParameter)
{
    TickType_t PreviousWakeTime;
    const TickType_t ELM327_Cyclic = 500;
    PreviousWakeTime = xTaskGetTickCount();
    while (1)
    {
			
        ELM327_ManageOngoingOperation();
        vTaskDelayUntil(&PreviousWakeTime, ELM327_Cyclic);
    }
}*/

/*void GPS_Task(void* PvParameter)
{
    TickType_t PreviousWakeTime;
    const TickType_t GPS_Cyclic = 300;
    PreviousWakeTime = xTaskGetTickCount();
    while (1)
    {
        GPS_ManagOnGoingOperation();
        vTaskDelayUntil(&PreviousWakeTime, GPS_Cyclic);
    }
}*/

/*
void DataHandler_Task(void* PvParameter)
{
    TickType_t PreviousWakeTime;
    const TickType_t DH_Cyclic = 150;
    PreviousWakeTime = xTaskGetTickCount();
    while (1)
    {
        DH_ManageOngoingOperation();
				GSM_ManageOngoingOperation();
        vTaskDelayUntil(&PreviousWakeTime, DH_Cyclic);
    }
}*/

/*void APP_Task(void* PvParameter)
{
    TickType_t PreviousWakeTime;
    const TickType_t APP_Cyclic = 50;
    PreviousWakeTime = xTaskGetTickCount();
    while (1)
    {
        APP_LocManageOnGoingOperations();
        vTaskDelayUntil(&PreviousWakeTime, APP_Cyclic);
    }
}*/

void APP_Auth_Task(void* PvParameter)
{
    TickType_t PreviousWakeTime;
    const TickType_t APP_Auth_Cyclic = 100;
    PreviousWakeTime = xTaskGetTickCount();
    while (1)
    {
				ELM327_ManageOngoingOperation();
				GPS_ManagOnGoingOperation();
			 APP_AuthManageOnGoingOperations();
				APP_LocManageOnGoingOperations();
        vTaskDelayUntil(&PreviousWakeTime, APP_Auth_Cyclic);
    }
}

void Auth_Task(void* PvParameter)
{
    TickType_t PreviousWakeTime;
    const TickType_t APP_Auth_Cyclic = 500;
    PreviousWakeTime = xTaskGetTickCount();
    while (1)
    {
				GSM_ManageOngoingOperation();
				if(count == 0)
				{
					DH_ManageOngoingOperation();
					count = 1;
					
				}
				else
				{
						count--;
				}
				
        vTaskDelayUntil(&PreviousWakeTime, APP_Auth_Cyclic);
    }
}

void Authentication_Task(void* PvParameter)
{
    TickType_t PreviousWakeTime;
    const TickType_t NVM_Cyclic = 100;
	
    PreviousWakeTime = xTaskGetTickCount();
	
    while(1)
    {
				I2C_Manager();
				NVM_Manager();
				BT_Manager();
				ButtonManage(0);
				KeyChangeManage();
        PW_Manage();
        vTaskDelayUntil(&PreviousWakeTime, NVM_Cyclic);
    }
}


void Error_CallBack(uint8_t ErrorID)
{
    //GPIO_Write(8,PIN_MASK_9,HIGH);
}
/*void Test (void)
{}
*/
int main(void)
{
    uint32_t LoopIndex;
		static Location Map = {"3112.3622",'N',"2932.1456",'E'};
    TaskHandle_t GSM_Handler = NULL;
		TaskHandle_t ELM327_Handler = NULL;
    TaskHandle_t GPS_Handler = NULL;
    TaskHandle_t DH_Handler = NULL;
		TaskHandle_t APP_Handler = NULL;
		TaskHandle_t APP_Auth_Handler = NULL;
		TaskHandle_t Authentication_Handler = NULL;
	uint8_t buffer[6]={'H','E','L','L','O',26};
    
    // Initialization
    GPIO_Init();
    for(LoopIndex = 0; LoopIndex < 50000; LoopIndex++);
    UART_Init();
		I2C_Init();
		Button_Init();
		GPS_Init();
    GSM_Init();
		ELM327_Init();
		BT_Init();
		GPIO_Write(8,PIN_MASK_9,HIGH);
		KeyInit();
	for(LoopIndex = 0; LoopIndex < 50000; LoopIndex++);
    DH_Init();
		NVM_Init();
    PW_Init();
		APP_Init();

    //DH_SendWarningSMS();
	  //DH_SendLocationToServer(&Map);
		//GSM_SendServerMsg("156.218.50.52", 13, "350", 3, buffer, 6);
		//ELM327_GetVehicleSpeed();
	
		/*NVM_Write(1,KeySt);
		while(NVM_SuccesWrite == 0)
		{
			I2C_Manager();
			NVM_Manager();
		}
		NVM_SuccesWrite = 0;*/

    NVIC_SetPriorityGrouping(4);
    //xTaskCreate(GPS_Task,"GPS",STACK_SIZE,NULL,2,&GPS_Handler);
    //xTaskCreate(GSM_Task,"GSM",STACK_SIZE,NULL,3,&GSM_Handler);
		//xTaskCreate(ELM327_Task,"ELM327",STACK_SIZE,NULL,3,&ELM327_Handler);
    //xTaskCreate(DataHandler_Task,"DataHandler",STACK_SIZE,NULL,3,&DH_Handler);
		xTaskCreate(Authentication_Task,"APP",STACK_SIZE,NULL,1,&APP_Handler);
		xTaskCreate(APP_Auth_Task,"APP_Auth",STACK_SIZE,NULL,1,&APP_Auth_Handler);
		xTaskCreate(Auth_Task,"UU",STACK_SIZE,NULL,2,&Authentication_Handler);
 
    vTaskStartScheduler();
    while(1)
    {

    }
    return 0;
}